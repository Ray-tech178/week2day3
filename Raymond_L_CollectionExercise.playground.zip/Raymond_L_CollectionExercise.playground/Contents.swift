import UIKit

var games : [String] = ["Stardew Valley","Terraria", "Battlefield V", "Grand Theft Auto V", "Killing Floor 2", "Astroneer", "Dying Light", "Ark Survival Evolved", "Slime Rancher", "Minecraft"]
let totalItem = games.count
